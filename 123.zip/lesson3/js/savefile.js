function writeTestFile(){
	
	console.log("lol");

	 var documentsDir;
	 var dir = tizen.filesystem;
	 var key1 = 0;
	 
	 
	 function onsuccess(files) {
	   for(var i = 0; i < files.length; i++) {
	     console.log("File Name is " + files[i].name); // displays file name
	     if (files[i].name==="TF1.txt"){
	    	 key1 = 55;
	     }
	     var str = document.getElementById("list_of_files").innerHTML;
	     document.getElementById("list_of_files").innerHTML = str + files[i].name + '; ';
	   }

	   console.log("11111111111111111");

	   var str = document.getElementById("list_of_files").innerHTML;
	   document.getElementById("list_of_files").innerHTML = str + '<br>';
	   
	   console.log("222222222222222222");
	   
	   if (key1===55) {
		   reWriteF();
	   }
	   else {
		   newWriteF();
	   }

	   function newWriteF(){
		   var testFile = documentsDir.createFile("TF1.txt");
		   console.log("TF = " + testFile);
		   /*if (testFile != null) { // проверка на существование*/		     
		   testFile.openStream(
		         "w",
		         function(fs){
		           fs.write("HelloWorld");
		           fs.close();
		         }, function(e){
		           console.log("Error " + e.message);
		         }, "UTF-8"
		     );
		   /*}*/
	   }
	   function reWriteF() {
		   console.log("REWRITE");
		   var newFile;
		   tizen.filesystem.resolve("documents", function(dir) 
			    {
			       newFile = documentsDir.resolve("TF1.txt");
			       newFile.openStream(
			        "w",
			        function(fs) {
			        	console.log("333333333333333333333333");
			        	 fs.write("456 456 456");
			        	 fs.close();
			        }, function(e) {
			        	 console.log("Error " + e.message);
			        }, "UTF-8");
			    });
			console.log("OK W");
		}
	  	  
	   /*var newFile = documentsDir.createFile("TF2.txt");
	   if (testFile != null) { // проверка на существование
		   var a = Math.random() * (100 - 1) + 1;
		   var str = 'file' + a + '.txt';
		   newFile = documentsDir.createFile(str);
	       newFile.openStream(
	  	         "w",
		         function(fs){
		           fs.write("HelloWorld");
		           fs.close();
		         }, function(e){
		           console.log("Error " + e.message);
		         }, "UTF-8"
		     );
	   }*/
	 }
	 function onerror(error) {
	   console.log("The error " + error.message + " occurred when listing the files in the selected folder");
	 }
	 

	 tizen.filesystem.resolve(
	     'documents',
	     function(dir){
	       documentsDir = dir; 
	       dir.listFiles(onsuccess,onerror);
	     }, function(e) {
	       console.log("Error" + e.message);
	     }, "rw"
	 );

}