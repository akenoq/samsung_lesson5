window.onload = function() {
    // TODO:: Do your initialization job

    // add eventListener for tizenhwkey
    document.addEventListener('tizenhwkey', function(e) {
        if (e.keyName === "back") {
            try {
                tizen.application.getCurrentApplication().exit();
            } catch (ignore) {}
        }
    });
        
};

function useFileReader()
{
	var element = document.getElementById('myF');
	element.click();
}

function workWithFile(files) {
	var file = files[0];
	var myReader = new FileReader();
	var ansString = "";
	myReader.readAsText(file);
	myReader.onload = function(e) {
		ansString = e.target.result;
		document.getElementById('file_cont').innerHTML = ansString;
	}
}